#pig latin

# take the first consonant of an English word,
# move it to the end of the word and add an ay,
# or if a word begins with a vowel you just add way to the end


# ie pig => igpay
#    latin => atinlay
#    egg => eegway

# make a program that translates english into pig latin and vice versa
